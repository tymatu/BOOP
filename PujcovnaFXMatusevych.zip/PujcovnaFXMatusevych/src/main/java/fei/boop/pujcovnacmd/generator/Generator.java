
package fei.boop.pujcovnacmd.generator;

import fei.boop.pujcovnacmd.data.LetadlovaLod;
import fei.boop.pujcovnacmd.data.Lodka;
import fei.boop.pujcovnacmd.data.NakladniLod;
import fei.boop.pujcovnacmd.data.VyletniLod;
import fei.boop.pujcovnacmd.kolekce.LinkSeznam;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Admin
 * @param <E>
 */
public class Generator<E> {
   private static ArrayList<String> jmena;
   private static final Random r = new Random();
   private static LinkSeznam<Lodka> zgenerovane = new LinkSeznam<>();
      
   
    private Generator() {
       
    }
   
   public static LinkSeznam generuj(int pocet){
       nactiJmena();
       
        double nahoda;
        String nahodneJmeno;
        double nahodnaHmotnost;
      
        
       for(int i = 0; i < pocet; i++){
           Lodka lodka = null;
           nahoda = r.nextDouble();
           nahodneJmeno = dejNahodnejmeno();
           nahodnaHmotnost = dejNahodnouHmotnost();
           if(nahoda<0.33){
              lodka = new NakladniLod(nahodneJmeno, nahodnaHmotnost , Lodka.cislo_id, dejPocetKontejneru(), dejCenaDodavky());
           }else if(nahoda<0.66){
              lodka = new LetadlovaLod(nahodneJmeno, nahodnaHmotnost, Lodka.cislo_id, dejNosnost(), dejPocetLetadel());
           }else{
              lodka = new VyletniLod(nahodneJmeno, nahodnaHmotnost, Lodka.cislo_id, dejCenu(),dejDelkaCesty());
           }
           zgenerovane.vlozPosledni(lodka);
       }
       return zgenerovane;
   }
   private static void nactiJmena(){
       try{
           jmena = new ArrayList<>(Files.readAllLines(Paths.get("names.txt")));
       }catch(IOException e){
           System.out.println("Chyba cteni");
       }
   }
   
   private static double dejNahodnouHmotnost(){
       return Math.round(r.nextDouble(10, 600000));
   }
   
   private static String dejNahodnejmeno(){
       return jmena.get(r.nextInt(jmena.size()));
   }
   
   private static int dejPocetKontejneru(){
       return r.nextInt(100,24000);
   }
   
   private static double dejCenaDodavky(){
       return Math.round(r.nextDouble(500, 3000));
   }
   
   private static double dejNosnost(){
       return r.nextInt(1000, 45000);
   }
   
   private static int dejPocetLetadel(){
       return r.nextInt(10,80);
   }
   
   private static double dejCenu(){
       return Math.round(r.nextDouble(1000, 6000000));
   }
   
   private static int dejDelkaCesty(){
       return r.nextInt(3, 100);
   }
}
