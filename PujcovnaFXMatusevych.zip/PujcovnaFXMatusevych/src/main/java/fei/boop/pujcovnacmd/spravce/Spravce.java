
package fei.boop.pujcovnacmd.spravce;

import fei.boop.pujcovnacmd.data.Lodka;
import fei.boop.pujcovnacmd.generator.Generator;
import fei.boop.pujcovnacmd.kolekce.KolekceException;
import fei.boop.pujcovnacmd.kolekce.LinkSeznam;
import fei.boop.pujcovnacmd.kolekce.SpojovySeznam;
import fei.boop.pujcovnacmd.perzistence.ZapisCteni;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 *
 * @author Admin
 * @param <E>
 */
public final class Spravce<E> implements Ovladani<E>, Iterable<E> {

    private SpojovySeznam<E> seznam;
    private Comparator<? super E> komparator;
    private Consumer<String> chyba;
    private E emptyElement;

    private Spravce() {
    }

    public static <E> Spravce creatSpravce(Supplier<SpojovySeznam<E>> creator) {
        Objects.requireNonNull(creator);
        Spravce<E> spravce = new Spravce<>();
        spravce.seznam = creator.get();
        spravce.emptyElement = null;
        return spravce;
    }

    @Override
    public E najdi(E klic) {
        if (komparator == null) {
            System.out.println("Neni nastaven komparator");
            return emptyElement;
        } else {
            return (E) seznam.stream()
                    .filter(obj -> komparator.compare(obj, klic) == 0)
                    .findFirst()
                    .orElse(emptyElement);
        }

    }

    @Override
    public E odeber(E klic) {
        E odebr = (E) seznam.stream()
                .filter(obj -> komparator.compare(obj, klic) == 0)
                .findFirst()
                .orElse(emptyElement);
        if (komparator == null) {
            System.out.println("Neni nastaven komparator");
            return emptyElement;
        } else {
            try {
                seznam.nastavPrvni();
                while (seznam.dejAktualni() != klic) {
                    seznam.dalsi();
                }
                seznam.odeberAktualni();

            } catch (KolekceException e) {
                chyba(e);
            }
        }

        return odebr;
    }

    @Override
    public E dej() {
        try {
            return seznam.dejAktualni();
        } catch (KolekceException ex) {
            chyba(ex);
        }
        return emptyElement;
    }

    @Override
    public E vyjmi() {
        try {
            return seznam.odeberAktualni();
        } catch (KolekceException ex) {
            chyba(ex);
        }
        return emptyElement;
    }

    @Override
    public void prvni() {
        try {
            seznam.nastavPrvni();
        } catch (KolekceException ex) {
            chyba(ex);
        }
    }

    @Override
    public void posledni() {
        try {
            seznam.nastavPosledni();
        } catch (KolekceException ex) {
            chyba(ex);
        }
    }

    @Override
    public void dalsi() {
        try {
            seznam.dalsi();
        } catch (KolekceException e) {
            chyba(e);
        }
    }

    @Override
    public int pocet() {
        int pocet = seznam.size();
        return pocet;
    }

    @Override
    public void obnov(String soubor) throws IOException {
        if (ZapisCteni.binarni.exists()) {
            try {
                seznam = ZapisCteni.nacti(ZapisCteni.binarni.getPath(), (LinkSeznam) seznam);

            } catch (IOException ex) {
                chyba(ex);
            }
        } else {
            System.out.println("Soubor neexistuje");
        }
    }

    @Override
    public void zalohuj(String soubor) throws IOException {
        try {
            ZapisCteni.uloz(ZapisCteni.binarni.getPath(), (LinkSeznam) seznam);
            System.out.println("Zalohovani probehlo uspesne");
        } catch (IOException ex) {
            chyba(ex);
        }
    }

    @Override
    public void nactiText(String soubor) throws IOException {
        try {
            ZapisCteni.readText(ZapisCteni.textovy.getPath(), (LinkSeznam) seznam);
            System.out.println("Nacteni probehlo uspesne");
        } catch (Exception e) {
            System.err.println("Doslo k chybe");
        }
    }

    @Override
    public void ulozText(String soubor) throws IOException {
        try {
            ZapisCteni.writeStream(((LinkSeznam) this.seznam).stream(), ZapisCteni.textovy.getPath());
            System.out.println("Ulozeni probehlo uspesne");
        } catch (FileNotFoundException | UnsupportedEncodingException ex) {
            chyba(ex);
        }
    }

    @Override
    public void generuj(int pocet) {
        Objects.requireNonNull(seznam);
        seznam = Generator.generuj(10);

    }

    @Override
    public void zrus() {
        seznam.zrus();
        Lodka.cislo_id = 1;
        System.out.println("Vsechny prvky seznamu byly zruseny");
    }

    @Override
    public Iterator<E> iterator() throws NoSuchElementException {
        return seznam.iterator();
    }

    @Override
    public void nastavChybu(Consumer<String> chyba) {
        Objects.requireNonNull(chyba);
        this.chyba = chyba;
    }

    public void chyba(Exception ex) {
        if (chyba == null) {
            System.out.println("Neni nastavena chyba");

        } else {
            chyba.accept((Spravce.class.getName()) + " " + ex);
        }
    }

    @Override
    public void edituj(Function<E, E> editor) {
        try {
            editor.apply(seznam.dejAktualni());
        } catch (KolekceException e) {
            chyba(e);
        }
    }

    @Override
    public void vloz(E data) throws NullPointerException {
        seznam.vlozPosledni(data);
    }

    @Override
    public Stream<E> stream() {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(seznam.iterator(), 0), false);
    }

    public boolean isAktNull() {
        try {
            seznam.dejAktualni();
            return true;
        } catch (KolekceException e) {
            return false;
        }
    }

    @Override
    public void predchozi() {
        try {
            Lodka akt = (Lodka) seznam.dejAktualni();
            seznam.nastavPrvni();
            while (seznam.jeDalsi()) {
                if (akt == seznam.dejPrvni()) {
                    throw new KolekceException();
                }
                if (seznam.dejZaAktualnim() != akt) {
                    seznam.dalsi();
                } else {
                    break;
                }
            }
        } catch (KolekceException e) {
            chyba(e);
        }

    }

    @Override
    public void nastavKomparator(Comparator<? super E> comparator) throws NullPointerException {
        Objects.requireNonNull(comparator);
        komparator = comparator;
    }

}
