
package fei.boop.pujcovnacmd.data;

/**
 *
 * @author Admnin
 */
public final class VyletniLod extends Lodka{

    private double cena;
    private int delkaCesty;

    public VyletniLod(String name, double hmotnostVtunach, int ID, double cena, int delkaCesty) {
        super(name,cislo_id++, hmotnostVtunach, TypLodky.VYLETNI_LOD);
        this.cena = cena;
        this.delkaCesty = delkaCesty;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public int getDelkaCesty() {
        return delkaCesty;
    }

    public void setDelkaCesty(int delkaCesty) {
        this.delkaCesty = delkaCesty;
    }
    
    @Override
    public String toString() {
        return "vyletni, " + getName() + ", " + getID() + ", " + getHmotnost() + ", " + cena + ", " + delkaCesty;
    }

    @Override
    public int compareTo(Lodka o) {
        return o.getID() == this.getID() ? 0 : -1;
    }
    
    
    
    
}
