
package fei.boop.pujcovnacmd.spravce;

/**
 *
 * @author Admin
 */
public class OvladaniException extends Exception{
    public OvladaniException(){
        
    }
}
