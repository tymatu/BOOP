
package fei.boop.pujcovnacmd.gui.Lodky;

import fei.boop.pujcovnacmd.data.Lodka;
import fei.boop.pujcovnacmd.data.NakladniLod;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.StageStyle;

/**
 *
 * @author Admin
 */
public final class DialogNakladniLod extends DialogLodka{

    private final Consumer<NakladniLod> vystupniOperace;
    private TextField tf_nazev;
    private TextField tf_hmotnost;
    private TextField tf_pocetKontejneru;
    private TextField tf_cenaDodavky;
    private boolean edit;
    private static boolean readOnly = false;
    private NakladniLod lodka;
    
    
    
    private DialogNakladniLod(Supplier<NakladniLod> vstup, Consumer<NakladniLod> vystup) {
        this.vystupniOperace = vystup;
        edit = vstup != null;
        lodka = (edit) ? vstup.get() : new NakladniLod("", 0, Lodka.cislo_id, 0, 0);
        
        setTitle("Dialog - Nakladni Lod");
        setWidth(300);
        setHeight(350);
        initStyle(StageStyle.UTILITY);
        initModality(Modality.APPLICATION_MODAL);
        setScene(getScena());      
        if(edit){
            set();
        }
    }
    
    public static DialogNakladniLod zobrazNakladniLod(Supplier<NakladniLod> vstup, Consumer<NakladniLod> vystup){
        readOnly = false;
        return new DialogNakladniLod(vstup, vystup);
    }
    
    public static DialogNakladniLod zobrazNakladniLod(Supplier<NakladniLod> vstup, Consumer<NakladniLod> vystup, boolean isReadOnly){
        readOnly = isReadOnly;
        return new DialogNakladniLod(vstup, vystup);
    }

    private Scene getScena() {
        VBox box = new VBox();
        box.setAlignment(Pos.CENTER);
        box.setSpacing(20);
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        box.getChildren().addAll(grid);
        int radek = 1;
        grid.add(new Label("ID"), 0, 0);
        grid.add(new Label(String.valueOf(lodka.getID())), 1, 0);
        tf_nazev = addRow(grid, "Nazev", radek++);
        tf_hmotnost = addRow(grid, "Hmotnost", radek++);
        tf_pocetKontejneru = addRow(grid, "Pocet kontejneru", radek++);
        tf_cenaDodavky = addRow(grid, "Cena dodavky ", radek++); 
        set();
        if(readOnly){
            setNotEditable();
        }
        Button buttonUloz = new Button("Uloz");
        buttonUloz.setOnAction(e -> {
            update();
            vystupniOperace.accept(lodka);
            hide();
        });
        grid.add(buttonUloz, 0, ++radek);

        Button buttonCancel = new Button("Cancel");
        buttonCancel.setOnAction(e -> {
            Lodka.cislo_id--;
            hide();
        });
        grid.add(buttonCancel, 1, radek);
        Scene scene = new Scene(box, 300, 350);
        return scene;
    }

    private static TextField addRow(GridPane grid, String nazev, int radek) {
        grid.add(new Label(nazev), 0, radek);
        TextField textField = new TextField();
        grid.add(textField, 1, radek);
        return textField;
    }

    private void update() {
        try {
            lodka.setName(tf_nazev.getText());
            lodka.setHmotnost(Double.parseDouble(tf_hmotnost.getText()));
            lodka.setPocetKontejneru(Integer.parseInt(tf_pocetKontejneru.getText()));
            lodka.setCenaDodavky(Double.parseDouble(tf_cenaDodavky.getText()));
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Spatne vstupni data");
            alert.show();
        }
    }

    private void set() {
        tf_nazev.setText(lodka.getName());
        tf_hmotnost.setText(String.valueOf(lodka.getHmotnost()));
        tf_pocetKontejneru.setText(String.valueOf(lodka.getPocetKontejneru()));
        tf_cenaDodavky.setText(String.valueOf(lodka.getCenaDodavky()));
    }
    
    private void setNotEditable(){
        tf_nazev.setEditable(false);
        tf_hmotnost.setEditable(false);
        tf_pocetKontejneru.setEditable(false);
        tf_cenaDodavky.setEditable(false);
    }

}
