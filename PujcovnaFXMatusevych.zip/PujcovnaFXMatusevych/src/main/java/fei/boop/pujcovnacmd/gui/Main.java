
package fei.boop.pujcovnacmd.gui;

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        AppFX.main(args);
    }
}
