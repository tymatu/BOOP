
package fei.boop.pujcovnacmd.perzistence;

import fei.boop.pujcovnacmd.data.LetadlovaLod;
import fei.boop.pujcovnacmd.data.Lodka;
import fei.boop.pujcovnacmd.data.NakladniLod;
import fei.boop.pujcovnacmd.data.VyletniLod;
import fei.boop.pujcovnacmd.kolekce.LinkSeznam;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;

/**
 *
 * @author Admin
 */
public class ZapisCteni {

    public static File binarni = new File("binarni.txt");
    public static File textovy = new File("textovy.txt");

    public static <E> void uloz(String jmenoSouboru, LinkSeznam seznam)
            throws IOException {
        try {
            Objects.requireNonNull(seznam);

            ObjectOutputStream vystup
                    = new ObjectOutputStream(
                            new FileOutputStream(jmenoSouboru));

            //vystup.reset();
            vystup.writeInt(seznam.size());

            Iterator<E> it = seznam.iterator();
            while (it.hasNext()) {
                vystup.writeObject(it.next());
            }
            vystup.close();
        } catch (IOException ex) {
            throw new IOException(ex);
        }
    }

    public static <E> LinkSeznam<E> nacti(String jmenoSouboru, LinkSeznam seznam)
            throws IOException {
        try {
            Objects.requireNonNull(seznam);
            ObjectInputStream vstup
                    = new ObjectInputStream(
                            new FileInputStream(jmenoSouboru));
            seznam.zrus();

            int pocet = vstup.readInt();
            for (int i = 0; i < pocet; i++) {
                seznam.vlozPosledni((E) vstup.readObject());
            }
            vstup.close();
        } catch (IOException | ClassNotFoundException ex) {
            throw new IOException(ex);
        } finally {
        }
        return seznam;
    }

    static Function<Lodka, String> mapperOutput = (prostredek) -> {
        switch (prostredek.getTyp()) {
            case NAKLADNI_LOD -> {
                return String.format("nl, %s, %5.0f, %d, %d, %5.0f",
                        prostredek.getName(), prostredek.getHmotnost(), prostredek.getID(),
                        ((NakladniLod) prostredek).getPocetKontejneru(),
                        ((NakladniLod) prostredek).getCenaDodavky());
            }
            case LETADLOVA_LOD -> {
                return String.format("ll, %s, %5.0f, %d, %5.0f, %d",
                        prostredek.getName(), prostredek.getHmotnost(), prostredek.getID(),
                        ((LetadlovaLod) prostredek).getNosnost(),
                        ((LetadlovaLod) prostredek).getPocetLetadel());
            }
            case VYLETNI_LOD -> {
                return String.format("vl, %s, %5.0f, %d, %5.0f, %d",
                        prostredek.getName(), prostredek.getHmotnost(), prostredek.getID(),
                        ((VyletniLod) prostredek).getCena(),
                        ((VyletniLod) prostredek).getDelkaCesty());
            }
        }
        return null;
    };

    public static void writeStream(
            Stream<Lodka> stream, String nameFile)
            throws FileNotFoundException, UnsupportedEncodingException {
        try (PrintWriter pw = new PrintWriter(nameFile, "UTF-8")) {
            stream
                    .map(mapperOutput)
                    .forEachOrdered(pw::println);
        }
    }

    public static void readText(String nameFile, LinkSeznam seznam) {
        BufferedReader reader = null;
        String line = "";
        Lodka lodka = null;
        try {
            reader = new BufferedReader(new FileReader(nameFile));
            while ((line = reader.readLine()) != null) {
                lodka = readLine(line);
                seznam.vlozPosledni(lodka);
            }
        } catch (IOException e) {
            System.out.println("Doslo k chybe");
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
            }
        }
    }

    private static Lodka readLine(String line) {
        Lodka prostredek = null;
        if (line.length() == 0) {
            return prostredek;
        }
        String[] items = line.split(",");
        String name = items[1].trim();
        float hmotnost = Float.parseFloat(items[2]);
        int id = Integer.parseInt(items[3].trim());
        switch (items[0].trim().toLowerCase(Locale.US)) {
            case "nl" -> {
                int pocetKontejneru = Integer.parseInt(items[4].trim());
                double cenaDodavky = Double.parseDouble(items[5].trim());
                prostredek = new NakladniLod(name, hmotnost, id, pocetKontejneru, cenaDodavky);
            }
            case "ll" -> {
                double nosnost = Double.parseDouble(items[4].trim());
                int pocetLetadel = Integer.parseInt(items[5].trim());
                prostredek = new LetadlovaLod(name, hmotnost, id, nosnost, pocetLetadel);
            }
            case "vl" -> {
                double cena = Double.parseDouble(items[4].trim());
                int delkaCesty = Integer.parseInt(items[5].trim());
                prostredek = new VyletniLod(name, hmotnost, id, cena, delkaCesty);
            }
        }

        return prostredek;
    }

}
