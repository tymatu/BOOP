package fei.boop.pujcovnacmd.gui;

import fei.boop.pujcovnacmd.data.LetadlovaLod;
import fei.boop.pujcovnacmd.data.Lodka;
import fei.boop.pujcovnacmd.data.NakladniLod;
import fei.boop.pujcovnacmd.data.TypLodky;
import fei.boop.pujcovnacmd.data.VyletniLod;
import fei.boop.pujcovnacmd.gui.Lodky.DialogNakladniLod;
import fei.boop.pujcovnacmd.gui.Lodky.DialogLetadlovaLod;
import fei.boop.pujcovnacmd.gui.Lodky.DialogVyletniLod;
import fei.boop.pujcovnacmd.kolekce.LinkSeznam;
import fei.boop.pujcovnacmd.perzistence.ZapisCteni;
import fei.boop.pujcovnacmd.spravce.Spravce;
import java.io.IOException;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * JavaFX App
 */
public class AppFX extends Application {

    private final int SCENE_WIDTH = 900;
    private final int SCENE_HEIGHT = 600;

    private ListView<Lodka> listView;
    private static Spravce<Lodka> spravce = Spravce.creatSpravce(() -> new LinkSeznam<Lodka>());

    ObservableList<String> cb_list = FXCollections.observableArrayList("nakladni", "letadlova", "vyletni");
    ObservableList<String> filtr_list = FXCollections.observableArrayList("nakladni", "letadlova", "vyletni", "bez filtru");
    ObservableList<String> najdi_list = FXCollections.observableArrayList("id", "name");

    //Zobrazeni chyby
    Consumer<String> chyba = (t) -> {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR");
        alert.setHeaderText("Doslo k chybe");
        alert.setContentText(t);
        alert.show();
    };
    //Handlery

    private final EventHandler<ActionEvent> generujHandler = event -> {
        spravce.generuj(10);
        obnovListView();
    };

    private final EventHandler<ActionEvent> nastavPrvniHandler = event -> {
        spravce.prvni();
        obnovListView(spravce.dej());
    };

    private final EventHandler<ActionEvent> dalsiHandler = event -> {
        spravce.dalsi();
        obnovListView(spravce.dej());
    };

    private final EventHandler<ActionEvent> predchoziHandler = event -> {
        spravce.predchozi();
        obnovListView(spravce.dej());
    };

    private final EventHandler<ActionEvent> nastavPosledniHandler = event -> {
        spravce.posledni();
        obnovListView(spravce.dej());
    };

    private final EventHandler<ActionEvent> editujHandler = event -> {
        if (spravce.isAktNull()) {
            Lodka lodka = spravce.dej();
            Stage dialog = null;
            TypLodky typ = lodka.getTyp();
            switch (typ) {
                case NAKLADNI_LOD -> {
                    dialog = DialogNakladniLod.zobrazNakladniLod(() -> (NakladniLod) lodka, t -> obnovListView());
                }
                case LETADLOVA_LOD -> {
                    dialog = DialogLetadlovaLod.zobrazLetadlovaLod(() -> (LetadlovaLod) lodka, t -> obnovListView());
                }
                case VYLETNI_LOD -> {
                    dialog = DialogVyletniLod.zobrazVyletniLod(() -> (VyletniLod) lodka, t -> obnovListView());
                }
            }
            dialog.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Neni nastaven aktualni prvek");
            alert.showAndWait();
        }

    };

    private final EventHandler<ActionEvent> vyjmiHandler = event -> {
        spravce.vyjmi();
        obnovListView();
    };

    private final EventHandler<ActionEvent> zobrazHandler = event -> {
        if (spravce.isAktNull()) {
            Lodka lodka = spravce.dej();
            Stage dialog = null;
            TypLodky typ = lodka.getTyp();
            switch (typ) {
                case NAKLADNI_LOD -> {
                    dialog = DialogNakladniLod.zobrazNakladniLod(() -> (NakladniLod) lodka, t -> obnovListView(), true);
                }
                case LETADLOVA_LOD -> {
                    dialog = DialogLetadlovaLod.zobrazLetadlovaLod(() -> (LetadlovaLod) lodka, t -> obnovListView(), true);
                }
                case VYLETNI_LOD -> {
                    dialog = DialogVyletniLod.zobrazVyletniLod(() -> (VyletniLod) lodka, t -> obnovListView(), true);
                }
            }
            dialog.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Neni nastaven aktualni prvek");
            alert.showAndWait();
        }
    };

    private final EventHandler<ActionEvent> clearHandler = event -> {
        obnovListView();
    };

    private final EventHandler<ActionEvent> ulozHandler = event -> {
        try {
            spravce.ulozText(ZapisCteni.binarni.getPath());
        } catch (IOException e) {
        }
    };

    private final EventHandler<ActionEvent> nactiHandler = event -> {
        try {
            spravce.nactiText(ZapisCteni.binarni.getPath());
        } catch (IOException e) {
        }
        obnovListView();
    };

    private final EventHandler<ActionEvent> zalohujHandler = event -> {
        try {
            spravce.zalohuj(ZapisCteni.binarni.getPath());
        } catch (IOException e) {
        }
    };

    private final EventHandler<ActionEvent> obnovHandler = event -> {
        try {
            spravce.obnov(ZapisCteni.binarni.getPath());
        } catch (IOException e) {
        }
        obnovListView();
    };

    private final EventHandler<ActionEvent> zrusHandler = event -> {
        spravce.zrus();
        obnovListView();
    };

    @Override
    public void start(Stage stage) {

        spravce.nastavChybu(chyba);
        var javaVersion = SystemInfo.javaVersion();
        var javafxVersion = SystemInfo.javafxVersion();
        stage.setTitle("Hello, JavaFX " + javafxVersion + ", running on Java " + javaVersion + ".");

        VBox root = new VBox();

        Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT);
        listView = createListView();
        VBox controlPanelRightVBox = createControlPanelRVBox();
        HBox hBox = new HBox();
        hBox.getChildren().addAll(listView, controlPanelRightVBox);
        HBox controlPanelHbox = createControlPanelHBox();
        root.getChildren().addAll(hBox, controlPanelHbox);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    private ListView<Lodka> createListView() {
        ListView<Lodka> list = new ListView<>();
        list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        list.setMinHeight(SCENE_HEIGHT - 60);
        list.setMinWidth(SCENE_WIDTH - 100);
        list.setBorder(new Border(new BorderStroke(Color.RED, BorderStrokeStyle.NONE, CornerRadii.EMPTY, BorderWidths.FULL)));

        list.setCellFactory(cell -> {
            return new ListCell<Lodka>() {
                @Override
                protected void updateItem(Lodka item, boolean empty) {
                    super.updateItem(item, empty);
                    if (!empty && item != null) {
                        setText(item.toString());
                        setFont(Font.font("Monospaced", 20));
                    } else {
                        setText("");
                    }
                }
            };
        });

        return list;
    }

    private VBox createControlPanelRVBox() {
        VBox vbox = new VBox();
        vbox.setSpacing(10);

        Label lbl_prochazeni = new Label("Procházení");
        Label lbl_prikazy = new Label("Příkazy");
        Button btn_prvni = addButtonVbox("prvni", nastavPrvniHandler);
        Button btn_dalsi = addButtonVbox("dalsi", dalsiHandler);
        Button btn_predchozi = addButtonVbox("predchozi", predchoziHandler);
        Button btn_posledni = addButtonVbox("posledni", nastavPosledniHandler);
        Button btn_edituj = addButtonVbox("Edituj", editujHandler);
        Button btn_vyjmi = addButtonVbox("Vyjmi", vyjmiHandler);
        Button btn_zobraz = addButtonVbox("Zobraz", zobrazHandler);
        Button btn_clear = addButtonVbox("Clear", clearHandler);
        VBox.setMargin(lbl_prochazeni, new Insets(10, 0, 0, 10));
        VBox.setMargin(lbl_prikazy, new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(lbl_prochazeni, btn_prvni, btn_dalsi, btn_predchozi, btn_posledni, lbl_prikazy, btn_edituj, btn_vyjmi, btn_zobraz, btn_clear);
        return vbox;
    }

    private HBox createControlPanelHBox() {
        HBox hBox = new HBox();
        hBox.setSpacing(10);

        Label lbl_novy = new Label("Nový:");
        Label lbl_filtr = new Label("Filtr:");

        HBox.setMargin(lbl_filtr, new Insets(20, 0, 0, 10));
        HBox.setMargin(lbl_novy, new Insets(20, 0, 0, 10));

        Button btn_generuj = addButtonHbox("Generuj", generujHandler);
        Button btn_uloz = addButtonHbox("Ulož", ulozHandler);
        Button btn_nacti = addButtonHbox("Načti", nactiHandler);
        Button btn_zalohuj = addButtonHbox("Zálohuj", zalohujHandler);
        Button btn_obnov = addButtonHbox("Obnov", obnovHandler);
        Button btn_zrus = addButtonHbox("Zruš", zrusHandler);
        HBox.setMargin(btn_generuj, new Insets(15, 0, 0, 15));

        ComboBox<String> cb_novy = addComboBox(cb_list, "Novy");
//        cb_novy.setPromptText("Novy");
//        HBox.setMargin(cb_novy, new Insets(15, 0, 0, 0));

        cb_novy.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            String vybrany = cb_novy.getValue();
            if (vybrany == null) {
                return;
            }
            Stage dialog = null;
            switch (vybrany) {
                case "nakladni" ->
                    dialog = DialogNakladniLod.zobrazNakladniLod(null, lodka -> {
                        try {
                            spravce.vloz(lodka);
                            obnovListView();
                        } catch (NullPointerException e) {
                        }
                    });

                case "letadlova" ->
                    dialog = DialogLetadlovaLod.zobrazLetadlovaLod(null, lodka -> {
                        try {
                            spravce.vloz(lodka);
                            obnovListView();
                        } catch (NullPointerException e) {
                        }
                    });

                case "vyletni" ->
                    dialog = DialogVyletniLod.zobrazVyletniLod(null, lodka -> {
                        try {
                            spravce.vloz(lodka);
                            obnovListView();
                        } catch (NullPointerException e) {
                        }
                    });
            }
            dialog.showAndWait();
        });
        ComboBox<String> cb_filtr = addComboBox(filtr_list, "Filtr");
        cb_filtr.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends String> ov, String t, String t1) -> {
            String vybrany = cb_filtr.getValue();
            ObservableList<Lodka> filtered = null;
            if (null == vybrany) {
                filtered = spravce.stream()
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
            } else {
                filtered = switch (vybrany) {
                    case "nakladni" ->
                        spravce.stream()
                        .filter(x -> x.getTyp() == TypLodky.NAKLADNI_LOD)
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                    case "letadlova" ->
                        spravce.stream()
                        .filter(x -> x.getTyp() == TypLodky.LETADLOVA_LOD)
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                    case "vyletni" ->
                        spravce.stream()
                        .filter(x -> x.getTyp() == TypLodky.VYLETNI_LOD)
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                    default ->
                        spravce.stream()
                        .collect(Collectors.toCollection(FXCollections::observableArrayList));
                };
            }
            listView.setItems(filtered);
        });
        ComboBox<String> cb_najdi = addComboBox(najdi_list, "Najdi");
        cb_najdi.getSelectionModel().selectedItemProperty().addListener((ov, t, t1) -> {
            String atribut = cb_najdi.getValue();
            if (atribut != null) {
                najdiDialog(atribut);
            }
        });
             
        hBox.getChildren().addAll(btn_generuj, btn_uloz, btn_nacti, lbl_novy, cb_novy, lbl_filtr, cb_filtr, cb_najdi, btn_zalohuj, btn_obnov, btn_zrus);
        return hBox;
    }

    private Button addButtonVbox(String text, EventHandler<ActionEvent> eventHandler) {
        Button bt = new Button(text);
        bt.setOnAction(eventHandler);
        VBox.setMargin(bt, new Insets(0, 0, 0, 10));
        bt.setMinWidth(80);
        return bt;
    }

    private Button addButtonHbox(String text, EventHandler<ActionEvent> eventHandler) {
        Button bt = new Button(text);
        bt.setOnAction(eventHandler);
        HBox.setMargin(bt, new Insets(15, 0, 0, 0));
        return bt;
    }

    private void obnovListView(Lodka lodka) {
        listView.getItems().clear();
        for (Lodka t : spravce) {
            listView.getItems().add(t);
        }
        listView.getSelectionModel().select(lodka);
        listView.scrollTo(lodka);
        listView.refresh();
    }

    private void obnovListView() {
        listView.getItems().clear();
        for (Lodka t : spravce) {
            listView.getItems().add(t);
        }
        listView.getSelectionModel().clearSelection();
        listView.refresh();
    }
    
    private ComboBox<String> addComboBox(ObservableList<String> list, String prompt){
        ComboBox<String> comboBox = new ComboBox<>(list);
        comboBox.setPromptText(prompt);
        HBox.setMargin(comboBox, new Insets(15, 0, 0, 0));
         comboBox.setCellFactory(param -> {
            final ListCell<String> cell = new ListCell<>() {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (!empty) {
                        setText(item);
                    }
                }
            };
            cell.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
                comboBox.setValue(null);
                comboBox.getSelectionModel().select(cell.getItem());
                e.consume();
            });
            return cell;
        });
         return comboBox;
    }

    private void najdiDialog(String atribut) {
        TextInputDialog input = new TextInputDialog();
        input.setTitle("Najdi - Dialog");
        input.setHeaderText("Zadej " + atribut);
        input.setContentText(atribut);
        final Lodka lodka;
        Optional<String> result = input.showAndWait();
        if (result.isPresent() && result.get().length() > 0) {
            if ("id".equals(atribut)) {
                lodka = spravce.stream()
                        .filter(lod -> lod.getID() == Integer.parseInt(result.get()))
                        .findFirst()
                        .orElse(null);
            } else {
                lodka = spravce.stream()
                        .filter(lod -> result.get().equals(lod.getName()))
                        .findFirst()
                        .orElse(null);
            }
            try {
                TypLodky typ = lodka.getTyp();
                Stage dialogNajdi = null;
                switch (typ) {
                    case NAKLADNI_LOD -> {
                        dialogNajdi = DialogNakladniLod.zobrazNakladniLod(() -> (NakladniLod) lodka, t -> obnovListView(), true);
                    }
                    case LETADLOVA_LOD -> {
                        dialogNajdi = DialogLetadlovaLod.zobrazLetadlovaLod(() -> (LetadlovaLod) lodka, t -> obnovListView(), true);
                    }
                    case VYLETNI_LOD -> {
                        dialogNajdi = DialogVyletniLod.zobrazVyletniLod(() -> (VyletniLod) lodka, t -> obnovListView(), true);
                    }
                }
                dialogNajdi.showAndWait();
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Nebyla nalezena zadna lodka");
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Neplatny input");
            alert.showAndWait();
        }
    }
}
