
package fei.boop.pujcovnacmd.data;

import java.io.Serializable;

/**
 *
 * @author Admin
 */

public abstract sealed class Lodka implements Serializable, Comparable<Lodka>
        permits NakladniLod, LetadlovaLod, VyletniLod{
    public static int cislo_id = 1;
    
    private String name;
    private double hmotnostV_t;
    private final TypLodky typ;
    private final int ID;

    public Lodka(String name, int identifikace, double hmotnostVtunach, TypLodky typ) {
        this.name = name;
        this.hmotnostV_t = hmotnostVtunach;
        this.typ = typ;
        this.ID = identifikace;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHmotnost() {
        return hmotnostV_t;
    }

    public void setHmotnost(double hmotnostVtunach) {
        this.hmotnostV_t = hmotnostVtunach;
    }

    public TypLodky getTyp() {
        return typ;
    }

    public int getID() {
        return ID;
    }

    @Override
    public String toString() {
        return "Lodka{" + "name=" + name + ", hmotnostV_t=" + hmotnostV_t + ", typ=" + typ + ", ID=" + ID + '}';
    }
    

   
    
    
   
    
    
}
