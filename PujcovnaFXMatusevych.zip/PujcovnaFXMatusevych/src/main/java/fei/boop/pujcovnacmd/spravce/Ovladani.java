
package fei.boop.pujcovnacmd.spravce;

import java.io.IOException;
import java.util.Comparator;
import java.util.Spliterators;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 *
 * @author Admin
 * @param <E>
 */
public interface Ovladani<E> extends Iterable<E> {

   

    /**
     * Metoda vloz() vloží data typu E za aktualně nastavený prvek.
     *
     * @param data Datova entita typu E
     * @throws NullPointerException Kdyz data je null.
     */
    void vloz(E data)throws NullPointerException;

    /**
     * Přístupová metoda najdi() vrátí odkaz na prvek v seznamu podle hodnoty
     * kliče.
     *
     * @param klic Datová entita typu E.
     * @return Odkaz na datovou entitu E.
     *
     * @throws OvladaniException Výjimka se vystaví, když je seznam prázdný.
     */
    E najdi(E klic) throws OvladaniException;

    /**
     * Metoda odeber() odebere prvek ze seznamu podle hodnoty klíče a propojí
     * zbylé prvky seznamu.
     *
     * Metoda mění aktuální počet objektů v seznamu.
     *
     * @param klic
     * @return Odkaz na odebíraný objekt, datovou entitu E.
     *
     * @throws OvladaniException tato výjimka se vystaváí, když nebyl nastaven
     * aktuální prvek nebo byl seznam prázdný.
     */
    E odeber(E klic) throws OvladaniException;

    /**
     * Přístupová metoda dej() vrátí v návratové hodnotě odkaz na aktuální prvek
     * v seznamu.
     *
     * @return vrací odkaz na aktuální object/datovou entitu typu E seznamu.
     *
     * @throws OvladaniException Tato výjimka se vystaví, když je seznam prázdný
     * nebo když není nastaven aktuální prvek.
     */
    E dej() throws OvladaniException;

    /**
     * Metoda edituj() spustí editaci aktuálního prvku v seznamu.
     *
     * @param editor
     * @throws OvladaniException Tato výjimka se vystaví, když je seznam prázdný
     * nebo když není nastaven aktuální prvek.
     */
    void edituj(Function<E,E> editor) throws OvladaniException;

    /**
     * Metoda vyjmi() odebere aktuální prvek ze seznamu a propojí zbylé prvky
     * seznamu.Metoda mění aktuální počet objektů v seznamu.
     *
     * Po odebrání aktuálního prvku bude aktuální prvek nedefinován.
     *
     *
     * @return Vraci odebrany prvek.
     * @throws OvladaniException tato výjimka se vystaváí, když nebyl nastaven
     * aktuální prvek nebo byl seznam prázdný.
     */
    E vyjmi() throws OvladaniException;

    /**
     * Metoda pohybu prvni() nastaví vnitřní aktuální ukazatel na první data
     * seznamu.
     *
     * @throws OvladaniException Výjimka se vystaví, když je seznam prázdný.
     */
    void prvni() throws OvladaniException;

    /**
     * Metoda pohybu posledni() nastaví vnitřní aktuální ukazatel na poslední
     * data seznamu.
     *
     * @throws OvladaniException Výjimka se vystaví, když je seznam prázdný.
     */
    void posledni() throws OvladaniException;
    
    /**
     * Metoda dalsi() posune aktualni prvek na dalsi prvek v seznamu.
     * 
     * @throws OvladaniException Kdyz aktualni prvek neni nastaven.
     */
    void dalsi() throws OvladaniException;
    
    /**
     * Metoda predchozi() posune aktualni prvek na predchozi prvek v seznamu.
     * 
     * @throws OvladaniException Kdyz aktualni prvek neni nastaven.
     */
    void predchozi() throws OvladaniException;
      

    /**
     * Metoda pocet() vrací aktuální počet dat v seznamu.
     *
     * @return Vrací hodnotu s počtem dat v seznamu.
     */
    int pocet();

    /**
     * Metoda obnov() obnoví seznam data z binárního souboru.
     *
     * Aktuální data seznamu budou přepsany.
     *
     * @param soubor Cesta k souboru.
     * @throws IOException Výjimka se vystaví, když cesta k souboru je neplatná.
     */
    void obnov(String soubor) throws IOException;

    /**
     * Metoda zalohuj() uloží aktuální seznam dat do binárního souboru.
     *
     * @param soubor Cesta k souboru.
     * @throws IOException Výjimka se vystaví, když cesta k souboru je neplatná.
     */
    void zalohuj(String soubor) throws IOException;


    /**
     * Metoda nactiText() načte data do seznamu z textového souboru.
     *
     * @param soubor Cesta k souboru.
     * @throws IOException Výjimka se vystaví, když cesta k souboru je neplatná.
     */
    void nactiText(String soubor) throws IOException;

    /**
     * Metoda ulozText() uloží data z seznamu do textového souboru.
     *
     * @param soubor Cesta k souboru.
     * @throws IOException Výjimka se vystaví, když cesta k souboru je neplatná.
     */
    void ulozText(String soubor) throws IOException;

    /**
     * Metoda generuj() Vygeneruje zadaný počet prvku a uloží je do seznamu.
     *
     * @param pocet Pocet generovaných prvku.
     */
    void generuj(int pocet);

    /**
     * Metoda zrus() odebere všechny data ze seznamu.
     */
    void zrus();
    
    /**
     * Metoda nastaví komparator
     * 
     * @param comparator 
     * @throws NullPointerException když parametr je null
     */
    void nastavKomparator(Comparator<? super E> comparator) throws NullPointerException;
    
    /**
     * Metoda příjme parametr a zpracuje vypis chyby
     * 
     * @param chyba 
     */
    void nastavChybu(Consumer<String> chyba);
    
    /**
     * Defaultni metoda vloz(), ktera vklada vice prvku najednou.
     * 
     * @param data vycet dat
     * @throws OvladaniException 
     */
    default void vloz(E ... data) throws OvladaniException{
        for(E d : data){
            vloz(d);
        }
    }
    
    default Stream<E> stream(){
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize(iterator(), 0), false);
    }

}
