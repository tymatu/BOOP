
package fei.boop.pujcovnacmd.gui.Lodky;

import javafx.stage.Stage;

/**
 *
 * @author Admin
 */
public abstract sealed class DialogLodka extends Stage
        permits DialogNakladniLod, DialogLetadlovaLod, DialogVyletniLod {   
}
