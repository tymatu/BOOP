
package fei.boop.pujcovnacmd.data;

/**
 *
 * @author Admin
 */
public final class NakladniLod extends Lodka {
    private int pocetKontejneru;
    private double cenaDodavky;

    public NakladniLod(String name, double hmotnostVtunach, int ID, int pocetKontejneru, double cenaDodavky) {
        super(name, cislo_id++, hmotnostVtunach, TypLodky.NAKLADNI_LOD);
        this.pocetKontejneru = pocetKontejneru;
        this.cenaDodavky = cenaDodavky;

    }

    public int getPocetKontejneru() {
        return pocetKontejneru;
    }

    public void setPocetKontejneru(int pocetKontejneru) {
        this.pocetKontejneru = pocetKontejneru;
    }

    public double getCenaDodavky() {
        return cenaDodavky;
    }

    public void setCenaDodavky(double cenaDodavky) {
        this.cenaDodavky = cenaDodavky;
    }

    @Override
    public String toString() {
        return "nakladni, " + getName() + ", " + getID() + ", " + getHmotnost() + ", " + pocetKontejneru + ", " + cenaDodavky;
    }
    
    @Override
    public int compareTo(Lodka o) {
        return o.getID() == this.getID() ? 0 : -1;
    }

}
