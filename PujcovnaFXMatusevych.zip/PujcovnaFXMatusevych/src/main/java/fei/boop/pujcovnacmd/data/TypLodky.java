
package fei.boop.pujcovnacmd.data;

/**
 *
 * @author Admin
 */
public enum TypLodky {
    NAKLADNI_LOD("nakladni lod"),
    LETADLOVA_LOD("letadlova lod"),
    VYLETNI_LOD("vyletni lod");
    
    private final String nazev;

    private TypLodky(String nazev) {
        this.nazev = nazev;
    }
    
    
    
}
