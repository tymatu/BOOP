package fei.boop.pujcovnacmd.kolekce;

/**

 * @author karel@simerda.cz
 */
public class KolekceException extends Exception {

    public KolekceException() {
    }

}
