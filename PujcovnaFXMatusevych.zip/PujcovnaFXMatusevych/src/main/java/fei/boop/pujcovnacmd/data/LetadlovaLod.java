
package fei.boop.pujcovnacmd.data;

/**
 *
 * @author Admin
 */
public final class LetadlovaLod extends Lodka{
    private double nosnost;
    private int pocetLetadel;
    
    public LetadlovaLod(String name, double hmotnostVtunach, int ID, double nosnost, int pocetLetadel) {
        super(name, cislo_id++, hmotnostVtunach, TypLodky.LETADLOVA_LOD);
        this.nosnost = nosnost;
        this.pocetLetadel = pocetLetadel;
    }

    public double getNosnost() {
        return nosnost;
    }

    public void setNosnost(double nosnost) {
        this.nosnost = nosnost;
    }

    public int getPocetLetadel() {
        return pocetLetadel;
    }

    public void setPocetLetadel(int pocetLetadel) {
        this.pocetLetadel = pocetLetadel;
    }
    
     
    @Override
    public String toString() {
        return "letadlova, " + getName() + ", " + getID() + ", " + getHmotnost() + ", " + nosnost + ", " + pocetLetadel;
    }
    
    @Override
    public int compareTo(Lodka o) {
        return o.getID() == this.getID() ? 0 : -1;
    }
}
