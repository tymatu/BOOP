module com.mycompany.pujcovnafxmatusevych {
    requires javafx.controls;
    exports fei.boop.pujcovnacmd.gui;
}
