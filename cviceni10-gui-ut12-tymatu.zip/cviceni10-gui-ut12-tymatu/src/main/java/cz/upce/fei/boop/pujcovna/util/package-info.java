package cz.upce.fei.boop.pujcovna.util;

/*
Balíček je určen pro zdrojové soubory s různými jednoduchými funkcemi, 
které se nehodí do jiných balíčků, ale jsou z nich využívány. 
*/
