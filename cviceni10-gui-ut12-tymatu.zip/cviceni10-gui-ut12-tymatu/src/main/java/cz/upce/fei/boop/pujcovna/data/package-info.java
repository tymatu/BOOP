package cz.upce.fei.boop.pujcovna.data;

/*
 * Balíček data je určen pro třídy s datovými entitami, jejichž instance se
 * vkládají, odebírají nebo vyzvedávají do/ze seznamu. 
 */
