package cz.upce.fei.boop.pujcovna.generator;

/*
   Balíček generator je určen pro zdrojové soubory, které zajišťují výrobu
   datových entit z balíčku data.
*/
