package cz.upce.fei.boop.pujcovna.perzistence;
/*
Balíček je určen pro zdrojové soubory, které zajišťují ukládání datových entit
do souborů a jejich načtení.
*/
